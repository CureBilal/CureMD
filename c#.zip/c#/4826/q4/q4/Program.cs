﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace q4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a number: "); //Taking input from the user
            int number = int.Parse(Console.ReadLine());

            int square = number * number; //squaring the numbers

            Console.WriteLine("The square of given numbers is: " + square);
            Console.ReadLine();
        }
    }
}
