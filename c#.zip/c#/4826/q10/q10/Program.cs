﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace q10
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the number of terms: "); // Taking the number from the user
            int n = int.Parse(Console.ReadLine());

            Console.WriteLine("Fibonacci sequence  terms:" + n);// Outputing the number of terms required for fibonaci series
            // declaring first two terms
            int first = 0;
            int second = 1;

            if (n >= 1)
            {
                Console.WriteLine(first);
            }

            if (n >= 2)
            {
                Console.WriteLine(second);
            }

            for (int i = 3; i <= n; i++) // For Loop with the condition for finding out new Fibonaci Terms
            {
                int next = first + second;
                Console.WriteLine(next);

                first = second;
                second = next;
                Console.ReadLine();
            }
        }
    }
}
