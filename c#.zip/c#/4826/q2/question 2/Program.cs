﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace question_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("What is your name?"); // Asking name from the user
            string name = Console.ReadLine();
            Console.WriteLine("Hello, " + name); //Outputing name with greeting
            Console.ReadLine();
        }
    }
}
