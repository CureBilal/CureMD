﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace q_6
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a number: "); //Taking the input from the user
            int n = int.Parse(Console.ReadLine());

            int sum = 0;
            for (int i = 1; i <= n; i = i + 1) //For condition for calculating the sum
            {
                sum = sum + i;
            }

            Console.WriteLine("The sum of numbers is:  " + sum);
            Console.ReadLine();
        }
    }
}
