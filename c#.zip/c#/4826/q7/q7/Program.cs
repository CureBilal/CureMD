﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace q7
{
    class Program
    {
        static void Main(string[] args)
        {
            // Taking input from user
            Console.WriteLine("Enter a number: ");
            int n = int.Parse(Console.ReadLine());

            Console.WriteLine("Multiplication table:" + n);
            Console.WriteLine();

            // Print table up to 12
            for (int i = 1; i <= 12; i++)
            {
                Console.WriteLine(" " + n * i);
                Console.ReadLine();
            }
        }
    }
}
