﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace q19
{
    class Program
    {
        static void Main(string[] args)
        { // Taking the number of rows from the user
            Console.Write("Enter the number of rows: ");
            int n = int.Parse(Console.ReadLine());

            for (int i = 1; i <= n; i++) // Applying For Loop's for making a pattern
            {
                for (int j = 1; j <= i; j++)
                {
                    Console.Write(j);
                }
                Console.WriteLine();
                Console.ReadLine();
            }
        }
    }
}
