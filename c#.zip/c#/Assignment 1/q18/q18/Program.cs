﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace q18
{
    class Program
    {
        static void Main(string[] args)
        { // Taking the number from the user as input
            Console.Write("Enter a number: ");
            int number = int.Parse(Console.ReadLine());

            int sum = 0;
            for (int i = 1; i < number; i++)
            {
                if (number % i == 0)
                {
                    sum += i; // sum = sum + i
                }
            }
            // Comparing the sum with the entered number by user to check if it is a perfect number or not
            if (sum == number)
            {
                Console.WriteLine(number + " is a perfect number.");
                Console.ReadLine();
            }
            else
            {
                Console.WriteLine(number + " is not a perfect number.");
                Console.ReadLine();
            }
        }
    }
}
    

