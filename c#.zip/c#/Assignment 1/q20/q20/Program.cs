﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace q20
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter the first string: ");
            string str1 = Console.ReadLine();

            Console.Write("Enter the second string: ");
            string str2 = Console.ReadLine();

            string longestCommonSubsequence = FindLongestCommonSubsequence(str1, str2);

            Console.WriteLine("Longest Common Subsequence: " + longestCommonSubsequence);
            Console.ReadLine();
        }

        static string FindLongestCommonSubsequence(string str1, string str2)
        {
            int m = str1.Length;
            int n = str2.Length;

            int[,] lengths = new int[m + 1, n + 1];

            for (int i = 0; i <= m; i++)
            {
                for (int j = 0; j <= n; j++)
                {
                    if (i == 0 || j == 0)
                    {
                        lengths[i, j] = 0;
                    }
                    else if (str1[i - 1] == str2[j - 1])
                    {
                        lengths[i, j] = lengths[i - 1, j - 1] + 1;
                    }
                    else
                    {
                        lengths[i, j] = Math.Max(lengths[i - 1, j], lengths[i, j - 1]);
                    }
                }
            }

            int lcsLength = lengths[m, n];
            char[] lcs = new char[lcsLength];

            int p = m, q = n;
            int index = lcsLength - 1;

            while (p > 0 && q > 0)
            {
                if (str1[p - 1] == str2[q - 1])
                {
                    lcs[index] = str1[p - 1];
                    p--;
                    q--;
                    index--;
                }
                else if (lengths[p - 1, q] > lengths[p, q - 1])
                {
                    p--;
                }
                else
                {
                    q--;
                }
            }

            return new string(lcs);
        }
    }
}
