﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace q17
{
    class Program
    {
        static void Main(string[] args)
        { // Taking the size of the array as input
            Console.Write("Enter the size of the array: ");
            int size = int.Parse(Console.ReadLine());
            // Intialization of the array
            int[] numbers = new int[size];

            Console.WriteLine("Enter the array elements:");

            for (int i = 0; i < size; i++)
            {
                Console.Write("Element " + (i + 1) + ": ");
                numbers[i] = int.Parse(Console.ReadLine());
            }

            Console.WriteLine("Original array:");
            foreach (int num in numbers)
            {
                Console.Write(num + " ");
            }
            Console.WriteLine();

            // Sort the array
            for (int i = 0; i < size - 1; i++)
            {
                for (int j = 0; j < size - 1 - i; j++)
                {
                    if (numbers[j] > numbers[j + 1])
                    {
                        // Swap elements
                        int temp = numbers[j];
                        numbers[j] = numbers[j + 1];
                        numbers[j + 1] = temp;
                    }
                }
            }
            // outputting the Sorted array
            Console.WriteLine("Sorted array:");
            foreach (int num in numbers)
            {
                Console.Write(num + " ");
            }
            Console.WriteLine();
            Console.ReadLine();
        }
    }
}
