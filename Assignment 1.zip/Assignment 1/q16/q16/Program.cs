﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace q16
{
    class Program
    {
        static void Main(string[] args)
        { // Taking a string as an input
            Console.Write("Enter a string: ");
            string input = Console.ReadLine();
            //Intialization of reversed String
            string reversed = "";

            for (int i = input.Length - 1; i >= 0; i--)
            {
                reversed += input[i]; //reversed = reserved + input[i]
            }

            Console.WriteLine("Reversed string: " + reversed);
            Console.ReadLine();
        }
    }
}
