﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace q11
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] numbers = new int[5];
            Console.WriteLine("Enter 5 numbers:");

            for (int i = 0; i < 5; i++)
            {
                Console.Write("Number: ");
                numbers[i] = int.Parse(Console.ReadLine());
            }

            Console.Write("Enter a number to search: ");
            int searchNumber = int.Parse(Console.ReadLine());

            bool found = false;
            for (int i = 0; i < 5; i++)
            {
                if (numbers[i] == searchNumber)
                {
                    Console.WriteLine("The number is found at index: " + i, + searchNumber);
                    found = true;
                }
            }

            if (!found)
            {
                Console.WriteLine("The number is not found in the array.");
            }

            Console.ReadLine();
        }
    }
}
