﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace q3
{
    class Program
    {
        static void Main(string[] args)
        {
            // Taking the input from user
            Console.WriteLine("Enter the first number: ");
            int number1 = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter the second number: ");
            int number2 = int.Parse(Console.ReadLine());
            // Declaring sum condition
            int sum = number1 + number2;

            Console.WriteLine("The sum of given numbers is: " + sum);
            Console.ReadLine();
        }
    }
}
