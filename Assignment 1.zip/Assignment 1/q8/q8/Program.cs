﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace q8
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a number: "); // Taking a number from the user 
            int n = int.Parse(Console.ReadLine());

            Console.WriteLine("Prime numbers up to:" + n);

            for (int i = 2; i <= n; i++) // For Loop for prime numbers
            {
                bool isPrime = true; // making a condition

                for (int j = 2; j <= i / 2; j++)
                {
                    if (i % j == 0) // If modulus is equal to zero than condition is false
                    {
                        isPrime = false;
                        break;
                    }
                }

                if (isPrime)
                {
                    Console.WriteLine(i);
                    Console.ReadLine();
                }
            }


        }
    } 

}
